package com.niit.EComFrontEnd.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.EcomBackend.DAO.UserDAO;
import com.niit.EcomBackend.Model.User;


@Controller
public class UserController {
	@Autowired
	UserDAO usedao;
 
	@RequestMapping(value =("/Register"))
		public String indexpage(Model m) 
	{
		m.addAttribute("user",new User());
		m.addAttribute("registerpage",true);
		m.addAttribute("haserror",false);
		m.addAttribute("error", "");
        return "index";
	}
	
	@RequestMapping(value ="/adduser", method= RequestMethod.POST)
	public String addcategory ( @Valid @ModelAttribute ("user") User user, BindingResult br,Model m) {
	   if (br.hasErrors()) { 				
				m.addAttribute("User", user);
				m.addAttribute("registerpage",true);
				m.addAttribute("haserror",true);
				m.addAttribute("error","please check ur data");
		        return "index";

			} 
	   else 
			{
				
				try
				{
					usedao.insertorupdateUser(user);
					return"redirect:/user";
					
					
				}
	   catch(Exception e )
	   {
	   
	    m.addAttribute("User",user);
		m.addAttribute("registerpage",true);
		m.addAttribute("haserror",true);
		m.addAttribute("error","Data Already Present");
		m.addAttribute("editmode",true);

	   }
}
	return "index";

	}

@RequestMapping(value ="/updateuse", method= RequestMethod.POST)
public String updateCategory ( @Valid @ModelAttribute ("user") User user, BindingResult br,Model m) {
   if (br.hasErrors()) { 				
			m.addAttribute("User", user);
			m.addAttribute("registerpage",true);
			m.addAttribute("haserror",true);
			m.addAttribute("error","please check ur data");
	        return "index";

		} 
   else 
		{
			
			try
			{
				usedao.insertorupdateUser(user);
				return"redirect:/user";
				
				
			}
   catch(Exception e )
   {
   
    m.addAttribute("User",user);
	m.addAttribute("registerpage",true);
	m.addAttribute("haserror",true);
	m.addAttribute("error","Data Already Present");
   }
}
return "index";

}

}
