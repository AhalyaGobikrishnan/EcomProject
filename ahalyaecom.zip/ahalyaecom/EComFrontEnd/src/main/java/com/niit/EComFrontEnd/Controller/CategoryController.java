package com.niit.EComFrontEnd.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.EcomBackend.DAO.CategoryDAO;
import com.niit.EcomBackend.Model.Category;


@Controller
public class CategoryController {
	@Autowired
	CategoryDAO catdao;
 
	@RequestMapping(value = ("/category") )
	public String indexpage(Model m) 
	{
		m.addAttribute("category",new Category());
		m.addAttribute("catlist",catdao.selectAll());
		m.addAttribute("categorypage",true);
		m.addAttribute("haserror",false);
		m.addAttribute("error", "");
		m.addAttribute("editmode",false);	
        return "index";
	}
	
	@RequestMapping(value ="/addcategory", method= RequestMethod.POST)
	public String addcategory ( @Valid @ModelAttribute ("category") Category category, BindingResult br,Model m) {
	   if (br.hasErrors()) { 				
				m.addAttribute("category", category);
				m.addAttribute("categorypage",true);
				m.addAttribute("haserror",true);
				m.addAttribute("error","please check ur data");
				m.addAttribute("catlist",catdao.selectAll());
				m.addAttribute("editmode",true);
		        return "index";

			} 
	   else 
			{
				
				try
				{
					catdao.insertorupdateCategory(category);
					return"redirect:/category";
					
					
				}
	   catch(Exception e )
	   {
	   
	    m.addAttribute("category",category);
		m.addAttribute("categorypage",true);
		m.addAttribute("haserror",true);
		m.addAttribute("error","Data Already Present");
		m.addAttribute("catlist",catdao.selectAll());
		m.addAttribute("editmode",true);

	   }
}
	return "index";

	}
	
@RequestMapping("/deletecat")
String delcatpage(@RequestParam("catname")String name,Model model)
{
	//use this if ur delete category method has name or id
	//catdao.deleteCategory(name);
	
	//use this if ur delete category method has Category as it paramete
	catdao.deleteCategory(catdao.selectOne(name));
	return "redirect:/category";		
}

@RequestMapping("/editcat")
String editcatpage(@RequestParam("catname")String name,Model model)
{
	model.addAttribute("title","DreamZone-Category");
	model.addAttribute("categorypage",true);	
	model.addAttribute("category",catdao.selectOne(name));
	model.addAttribute("catlist",catdao.selectAll());
	model.addAttribute("haserror",false);
	model.addAttribute("error","");
	model.addAttribute("editmode",true);
	return "index";		
}

@RequestMapping(value ="/updatecat", method= RequestMethod.POST)
public String updateCategory ( @Valid @ModelAttribute ("category") Category category, BindingResult br,Model m) {
   if (br.hasErrors()) { 				
			m.addAttribute("category", category);
			m.addAttribute("categorypage",true);
			m.addAttribute("haserror",true);
			m.addAttribute("error","please check ur data");
			m.addAttribute("catlist",catdao.selectAll());
			m.addAttribute("editmode",true);
	        return "index";

		} 
   else 
		{
			
			try
			{
				catdao.insertorupdateCategory(category);
				return"redirect:/category";
				
				
			}
   catch(Exception e )
   {
   
    m.addAttribute("category",category);
	m.addAttribute("categorypage",true);
	m.addAttribute("haserror",true);
	m.addAttribute("error","Data Already Present");
	m.addAttribute("catlist",catdao.selectAll());
	m.addAttribute("editmode",true);

   }
}
return "index";

}

}
