package com.niit.EComFrontEnd.Controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.niit.EcomBackend.DAO.CategoryDAO;
import com.niit.EcomBackend.DAO.ProductDAO;
import com.niit.EcomBackend.Model.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDAO prodao;
	
	@Autowired
	CategoryDAO catdao;

	void fileupload(MultipartFile f, int pi) {
		try {
			String path = "C:\\Users\\admin\\eclipse-workspace\\EComFrontEnd\\src\\main\\webapp\\resources\\pimage\\";
			path = path + String.valueOf(pi) + ".jpg";
			if (f != null) {
				byte[] b = f.getBytes();
				File newfile = new File(path);
				if (newfile.exists()) {
					newfile.delete();
					BufferedOutputStream b1 = new BufferedOutputStream(new FileOutputStream(newfile));
					b1.write(b);
					b1.close();
				} else {
					BufferedOutputStream b1 = new BufferedOutputStream(new FileOutputStream(newfile));
					b1.write(b);
					b1.close();
				}
			}
		} catch (Exception e) {

		}
	}

	@RequestMapping(value = ("/product"))
	public String indexpage(Model m) {
		m.addAttribute("product", new Product());
		m.addAttribute("prolist", prodao.selectAll());
		m.addAttribute("catlist",catdao.selectAll());
		m.addAttribute("productpage", true);
		m.addAttribute("haserror", false);
		m.addAttribute("error", "");
		m.addAttribute("editmode", false);
		return "index";
	}

	@RequestMapping(value = "/addproduct", method = RequestMethod.POST)
	public String addcategory(@Valid @ModelAttribute("product") Product product, BindingResult br, Model m) {
		if (br.hasErrors()) {
			m.addAttribute("Product", product);
			m.addAttribute("productpage", true);
			m.addAttribute("haserror", true);
			m.addAttribute("error", "please check ur data");
			m.addAttribute("prolist", prodao.selectAll());
			m.addAttribute("catlist", catdao.selectAll());
			m.addAttribute("editmode", true);
			return "index";

		} else {

			try {
				if (prodao.insertorupdateProduct(product))
					fileupload(product.getProductimage(), product.getProductId());
				return "redirect:/product";

			} catch (Exception e) {

				m.addAttribute("Product", product);
				m.addAttribute("productpage", true);
				m.addAttribute("haserror", true);
				m.addAttribute("error", "Data Already Present");
				m.addAttribute("prolist", prodao.selectAll());
				m.addAttribute("catlist", catdao.selectAll());

				m.addAttribute("editmode", true);

			}
		}
		return "index";

	}

	@RequestMapping("/deletepro")
	String delcatpage(@RequestParam("proname") String name, Model model) {
		// use this if ur delete category method has name or id
		// catdao.deleteCategory(name);

		// use this if ur delete category method has Category as it parameter
		prodao.deleteProduct(prodao.selectOne(name));
		return "redirect:/product";
	}

	@RequestMapping("/editpro")
	String editcatpage(@RequestParam("proname") String name, Model model) {
		model.addAttribute("title", "Product");
		model.addAttribute("productpage", true);
		model.addAttribute("product", prodao.selectOne(name));
		model.addAttribute("prolist", prodao.selectAll());
		model.addAttribute("catlist", catdao.selectAll());

		model.addAttribute("haserror", false);
		model.addAttribute("error", "");
		model.addAttribute("editmode", true);
		return "index";
	}

	@RequestMapping(value = "/updatepro", method = RequestMethod.POST)
	public String updateCategory(@Valid @ModelAttribute("product") Product product, BindingResult br, Model m) {
		if (br.hasErrors()) {
			m.addAttribute("Product", product);
			m.addAttribute("productpage", true);
			m.addAttribute("haserror", true);
			m.addAttribute("error", "please check ur data");
			m.addAttribute("prolist", prodao.selectAll());
			m.addAttribute("catlist", catdao.selectAll());

			m.addAttribute("editmode", true);
			return "index";

		} else {

			try {
				if(prodao.insertorupdateProduct(product))
					fileupload(product.getProductimage(),product.getProductId());
				return "redirect:/product";

			} catch (Exception e) {

				m.addAttribute("Product", product);
				m.addAttribute("productpage", true);
				m.addAttribute("haserror", true);
				m.addAttribute("error", "Data Already Present");
				m.addAttribute("prolist", prodao.selectAll());
				m.addAttribute("catlist", catdao.selectAll());

				m.addAttribute("editmode", true);

			}
		}
		return "index";

	}


@RequestMapping("/viewallproduct")
public String viewallproduct(Model model) 
{
   
 model.addAttribute("prolist", prodao.selectAll());
 model.addAttribute("viewallproductpage",true);
 return "index";
}

@RequestMapping("/viewoneproduct")
public String viewoneproduct(@RequestParam("pname")String pname,Model model) 
{
   
 model.addAttribute("prolist", prodao.selectOne(pname));
 model.addAttribute("viewoneproductpage",true);
 return "index";
}
}

