//package com.niit.EcommBack;
//
//import static org.junit.Assert.assertEquals;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.niit.EcommBack.DataAccess.ProductDAO;
//import com.niit.EcommBack.model.Product;
//
//public class TestProductDAO {
//	@Autowired
//	ProductDAO productDAO;
//	Product p=new Product();
//
//	@Before
//	public void setUp() throws Exception
//	{
//		p.setProductName("vanilla");
//		p.setPrice(500);
//		p.setProductDescription("have a tasty cake");
//		p.setQuantity(5);
//	
//	}
//	
//	@After
//	public void tearDown() throws Exception{
//	
//		//productDAO.deleteProduct("vanilla");
//	}
//
//	@Test
//	public void test() 
//	{
//		assertEquals("Success",true,productDAO.addProduct(p));
//		
//	}
//
//}
//
