package com.niit.EcommBack;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.niit.EcommBack.DataAccess.CategoryDAO;
import com.niit.EcommBack.model.Category;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Config.class, loader = AnnotationConfigContextLoader.class)
public class TestCategoryDAO {
	@Autowired
	CategoryDAO categorydao;
	 Category category = new Category();
	
	

	@Before
	public void setUp() throws Exception {
		category.setCategoryName("cakes");
		category.setCategoryDescription("cakes Description");
	}

	@After
	public void tearDown() {
		//categorydao.deleteCategory("jeans ");
	}

	@Test
	public void test() 
	{
		categorydao.addCategory(category);
		category=categorydao.showCategory("cakes");
		category.setCategoryDescription("error");
		categorydao.addCategory(category);
		assertSame(category.getCategoryDescription(), categorydao.showCategory("cakes").getCategoryDescription());
		List<Category> list = categorydao.showAllCategory();
		assertTrue("success", list.size()>0);
	}

}